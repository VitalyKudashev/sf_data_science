import numpy as np
def game_core_v3(number: int = 1) -> int:
    """
    Функция для угадывания числа методом бинарного поиска.
    Гарантированно находит число за 7 попыток или меньше (для диапазона 1-100).
    
    Args:
        number (int, optional): Загаданное число в диапазоне 1-100. Defaults to 1.

    Returns:
        int: Число попыток
    """
    count = 0
    low = 1
    high = 100
    
    while low <= high:
        count += 1
        mid = (low + high) // 2
        
        if mid == number:
            return count
        elif mid < number:
            low = mid + 1
        else:
            high = mid - 1
    
    return count  # Этот return фактически никогда не выполнится для корректного ввода

#Особенности реализации:
# Бинарный поиск оптимальный алгоритм для этой задачи
# Максимум 7 попыток этого достаточно для диапазона 1-100 (2^7 = 128 > 100)
# Гарантированная эффективность работает значительно быстрее требования в 20 попыток

# Проверка работы:
# Функция для тестирования (предполагается, что она уже определена)
def score_game(random_predict):
    count_ls = []
    np.random.seed(1)
    random_array = np.random.randint(1, 101, size=(1000))
    for number in random_array:
        count_ls.append(random_predict(number))
    score = int(np.mean(count_ls))
    print(f"Ваш алгоритм угадывает число в среднем за {score} попыток")
    return score